const menu1 = (prefix, pushname2, jam, tanggal, menu1) => {
        return `
*🔰⚜️ ${name} ⚜️️️🔰*
*🔅NAMA:* ${pushname2}
*🔅JAM:* ${jam} *WIB*
*🔅KALENDER:* ${tanggal}
*🔅PENGGUNA:* ${user.length} *PENGGUNA*

*🔰⚜️ MENU1 ⚜️️️🔰*
*♻️ ${prefix}info*
*♻️ ${prefix}owner
*♻️ ${prefix}donasi*
*♻️ ${prefix}speed*
*♻️ ${prefix}verify*
*♻️ ${prefix}blocklist*
*♻️ ${prefix}banlist*
*♻️ ${prefix}totaluser*
*🔰⚜️ MENU1 ⚜️️️🔰*

`
}
exports.menu1 = menu1
